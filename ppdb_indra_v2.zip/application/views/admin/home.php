
                        <marquee><h3 class="counttype text-light">Selamat Datang di Administrator PSB SMP PNIEL MEDAN</h3></marquee>
                        