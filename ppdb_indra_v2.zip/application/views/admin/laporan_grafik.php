<script src="<?=base_url()?>node_modules/chart.js/dist/chart.js"></script>
<body class="wide comments example dt-example-bootstrap">
	<a name="top" id="top"></a>
	<div class="fw-background">
		<div></div>
	</div>
	<div class="fw-container">
		<div class="fw-header">
			<div class="nav-search">
				<div class="nav-item i-user">
					<div class="account"></div>
				</div>
			</div>
		</div>
		<div class="fw-body">
			<div class="container">
				<h1>Laporan Dalam Bentuk Grafik</h1>
				<div class="col-md-12">
					<div class="form-group">
					  <label for="">Pilih Jenis Laporan</label>
					  <select name="jenis_laporan" onchange="jenis_laporan()" class="form-control" id="jenis_laporan">
						  <option value="">Pilih Jenis Laporan</option>
						  <option value="bulan">Bulanan</option>
						  <option value="tahun">Tahunan</option>
					  </select>
					  <small id="helpId" class="text-error ejenis_laporan"></small>
					</div>
					<div class="form-group select-bulan" hidden>
					  <label for="">Pilih Bulan</label>
					  <select name="bulan" class="form-control" id="bulan">
						  <option value="">Pilih Bulan</option>
						  <option value="01">Januari</option>
						  <option value="02">Februari</option>
						  <option value="03">Maret</option>
						  <option value="04">April</option>
						  <option value="05">Mei</option>
						  <option value="06">Juni</option>
						  <option value="07">Juli</option>
						  <option value="08">Agustus</option>
						  <option value="09">September</option>
						  <option value="10">Oktober</option>
						  <option value="11">November</option>
						  <option value="12">Desember</option>
					  </select>
					  <small id="helpId" class="text-error ebulan"></small>
					</div>
					<div class="form-group select-tahun" hidden>
					  <label for="">Pilih Tahun</label>
					  <select name="tahun" class="form-control" id="tahun">
						  <option value="">Pilih Tahun</option>
						  <option value="2019">2019</option>
						  <option value="2020">2020</option>
						  <option value="2021">2021</option>
						  <option value="2022">2022</option>
						  <option value="2023">2023</option>
						  <option value="2024">2024</option>
						  <option value="2025">2025</option>
						  <option value="2026">2026</option>
						  <option value="2027">2027</option>
						  <option value="2028">2028</option>
						  <option value="2029">2029</option>
						  <option value="2030">2030</option>
					  </select>
					  <small id="helpId" class="text-error etahun"></small>
					</div>
					<button type="button" onclick="searchData()" class="btn btn-success"><i class="fa fa-search"></i> Cari</button>
				</div>
				<div class="col-md-12 show-chart">
				<canvas id="chart-data"></canvas>
				</div>
			</div>
		</div>
		</table>
</body>
<script>
	let url="<?=base_url()?>";
	$(document).ready(function () {
		makeChart(1);
	});
	function jenis_laporan() {
		let jenis_laporan = $('#jenis_laporan').children("option:selected").val();
		if (jenis_laporan=='bulan') {
			$('.select-bulan').show();
			$('.select-tahun').show();
		} else if (jenis_laporan=='tahun') {
			$('.select-bulan').hide();
			$('.select-tahun').show();
		} else {
			$('.select-bulan').hide();
			$('.select-tahun').hide();
		}
	 }
	 function searchData() {
		 let jenis_laporan = $('#jenis_laporan').children("option:selected").val();
		 let bulan = $('#bulan').children("option:selected").val();
		 let tahun = $('#tahun').children("option:selected").val();
		 $.ajax({
			 type: "POST",
			 url: url+"ApiAdmin/makeChart",
			 data: {
				 jenis_laporan:jenis_laporan,
				 bulan:bulan,
				 tahun:tahun
			 },
			 dataType: "JSON",
			 success: function (response) {
				 if (response.status=='success') {
		 $(".show-chart").html('');
		 $(".show-chart").html('<canvas id="chart-data"></canvas>');
					 makeChart(response);
				 }
			 },error:function(){
				 swal({
					 title: "Gagal",
					 text: "Data Gagal Ditampilkan",
					 icon: "error",
					 button: "Ok",
				 });
			 }
		 });
	 }
function makeChart(response) {
	const labels = response.data.label;

  const data = {
    labels: labels,
    datasets: [{
      label: 'Peserta Lulus',
      backgroundColor: 'rgb(255, 99, 132)',
      borderColor: 'rgb(255, 99, 132)',
      data: response.data.lulus,
    },{
		label: 'Peserta Tidak Lulus',
      backgroundColor: 'rgb(255, 20, 132)',
      borderColor: 'rgb(255, 99, 132)',
      data: response.data.tidak_lulus,
	},{
		label: 'Total Peserta',
      backgroundColor: 'rgb(255, 20, 50)',
      borderColor: 'rgb(255, 99, 132)',
      data: response.data.peserta,
	}]
  };

  const config = {
    type: 'bar',
    data: data,
    options: {}
  };
  const myChart = new Chart(
    document.getElementById('chart-data'),
    config
  );
  }
</script>
