

<form target="_blank" action="<?=base_url('ControllerAdmin/cetak_tidak_lulus')?>" method="POST">
<table class="table  table-bordered">
    <tr>
        <td colspan="2" align="center"><h3>Laporan Tahunan Pendaftar</h3></td>
    </tr>
     <tr>
        <td>Masukan Tahun </td>
        <td>
        <select name="year" class="form-control1">
            <option value="0">--Tahun--</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
            <option value="2028">2028</option>
            <option value="2029">2029</option>
            <option value="2030">2030</option>
        </select>
        </td>
     </tr>
     <tr>
         <td colspan="2"><input type="submit" name="submit" value="cetak" class="btn btn-danger"></td>
     </tr>
</table>
</form>
