<div class="inner_page_agile"></div>
                                <!-- Gallery -->
                <div class="gallery">
                    <div class="container">
                        <div class="title-div">
                            <h3 class="tittle" style="Font-Family:Times New Roman">
                                <span></span>Detail Berita
                                </h3>
                            <div class="tittle-style">
                        </div>
                    </div>
                    <div class="about">
                        <div class="container">
                            <div class="about-grids">

            <div class="col-md-5 wthree-about-left">
                <div class="wthree-about-left-info">
                    <img witdh="500px" height="290px" src="<?=base_url('uploads/' . $pengumuman->foto_pengumuman)?>" alt="" />
            </div>
                </div>
                    <div class="col-md-7 agileits-about-right">
                        <h4 style="color:black; Font-size:20"><?=$pengumuman->judul_pengumuman . "," . $date?></h4>
                            <p align="justify"  style="color:black; Font-Family:Times New Roman" ><?=$pengumuman->isi_pengumuman;?></p>
                                </p>
                            </div>

                    <div class="clearfix"> </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 </div>
