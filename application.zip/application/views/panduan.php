<div
		class="inner_page_agile">
	</div>
		<div class="container">
			<div class="title-div">
				<div class="tittle-style">

				</div>
			</div>
			<div class="about-sub">
				<div class="col-md-6 about_bottom_left">
					<h4>Welcome to
						<span>Panduan</span>
					</h4 align="justify">
                    <p>1.Melakukan Registrasi Online Untuk Membuat Akun<br>
                    2.Melengkapi Formulir Online Pada Akun Ketika Sudah Login<br>
                    3.Hasil Kelulusan Bisa Di Lihat Di Akun Masing-Masing Pada Menu Pengumuman</p>
                    <a class="button-style" href="?page=register1">Daftar Now</a>
				</div>
				<!-- Stats-->
				<div class="col-md-6 about2-info">
					<img src="images/graduate.png" alt="" />
				</div>
				<!-- //Stats -->
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
