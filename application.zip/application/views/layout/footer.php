<div class="mkl_footer">
		<div class="sub-footer">
			<div class="container">
				<div class="mkls_footer_grid">
					<div class="col-xs-4 mkls_footer_grid_left">
						<h4 class="fa fa-map-marker">Lokasi:</h4>
						<p> Jl. Perjuangan Gg. Pisang No. 1 Pasar IV, Deli Tua
							<br> Kec. Namo Rambe, Sumatera Utara</p>
					</div>
					<div class="col-xs-4 mkls_footer_grid_left">
						<h4 class="fa fa-envelope">Email:</h4>
						<p>
							<span>Phone : </span>(0254) 387078</p>
						<p>
							<span>Email : </span>
							<a href="mailto:smppnielmedan@gmail.com">smppnielmedan@gmail.com</a>
						</p>
					</div>
					<div class="col-xs-4 mkls_footer_grid_left">
						<h4 class="fa fa-home">Buka:</h4>
						<p>Setiap Hari : 08-15.WIB</p>
						<p>Minggu
							<span>(Libur)</span>
						</p>
					</div>
					<div class="clearfix"> </div>
				</div>

				<!-- footer-button-info -->
				<div class="footer-middle-thanks">
				</div>
				<!-- footer-button-info -->
			</div>
		</div>
		<div class="footer-copy-right">
			<div class="container">
				<div class="allah-copy">
					<p>© 2022 | IT DEV

					</p>
				</div>
				<div class="footercopy-social">
					<ul>
						<li>
							<a href="#">
								<span class="fa fa-facebook"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-rss"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-vk"></span>
							</a>
						</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
