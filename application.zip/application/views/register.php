<style>
	.text-error{
		color: red;
	}
</style>
<div class="inner_page_agile"></div>
<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					From Register
				</h3>
				<div class="tittle-style">

				</div>
			</div>
			<div class="login-form">
			<form action="#" method="POST">
					<div class="">
						<p>NISN </p>
						<input class="form-control" type="text" name="nisn" id="nisn" placeholder="Masukkan NISN" required="">
						<span class="text-error enisn"></span>
					</div>
					<div class="">
						<p>Nama Lengkap</p>
						<input class="form-control" type="text" name="nama_lengkap" id="nama_lengkap" placeholder="Masukan Nama Lengkap" required="">
						<span class="text-error enama_lengkap"></span>
					</div>
					<div class="">
						<p>Username</p>
						<input class="form-control" type="text" name="user" id="user" placeholder="Masukan Username" required="">
						<span class="text-error euser"></span>
					</div>
					<div class="">
						<p>Password</p>
						<input class="form-control" type="password" name="pass" id="pass" placeholder="Masukan Password" required="">
						<span class="text-error epass"></span>
					</div>
					<label class="anim">
						<input type="checkbox" class="checkbox">
						<span>I Accept Terms &amp; Conditions</span>
					</label>
					<input type="button" class="btn btn-danger" onclick="registerData()" name="simpan" value="Register">
				</form>
			</div>
		</div>
	<section class="contact pb-8" id="contact">
				<!-- //contact form -->
			</div>
				<!-- map -->
				<div class="col-lg-12 map" data-aos="flip-left" data-aos-easing="ease-out-cubic" data-aos-duration="2000">
					<iframe src="" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				</div>
				<!-- //map -->
		</div>
	</section>
	<script>
		let url="<?=base_url()?>";
		function registerData() {
			$(".text-error").text("");
			let data= {
				nisn: $('#nisn').val(),
				nama_lengkap: $('#nama_lengkap').val(),
				user: $('#user').val(),
				pass: $('#pass').val(),
			}
			$.ajax({
				type: "POST",
				url: url+"controller/register_v2",
				data: data,
				dataType: "JSON",
				success: function (response) {
					if (response.status=='success') {
						swal({
							title: "Berhasil",
							text: "Anda Berhasil Register, silahkan login",
							icon: "success",
							button: "OK",
						}).then(function() {
							window.location.href = url+"controller/routePage/login";
						});
					} else if(response.status=='validation_failed'){
						$(".euser").text(response.errors.user);
						$(".enama_lengkap").text(response.errors.nama_lengkap);
						$(".enisn").text(response.errors.nisn);
						$(".epass").text(response.errors.pass);
					}
				},error:function(){
					swal({
						title: "Gagal",
						text: "Data Gagal Di Simpan",
						icon: "error",
						button: "Ok",
					});
				}
			});
		 }
	</script>
	<?php if ($this->session->flashdata('error')) {
    echo '
	<script>
		swal({
			title: "Gagal!",
			text: "Register Gagal, Username Sudah Terdaftar",
			type: "error",
			confirmButtonText: "Ok"
		});
	</script>';
}?>
