<div class="inner_page_agile"></div>
<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					From Register
				</h3>
				<div class="tittle-style">

				</div>
			</div>
			<div class="login-form">
			<form action="<?=base_url('controller/register')?>" method="POST">
					<div class="">
						<p>NISN </p>
						<input class="form-control" type="text" name="nisn" placeholder="Masukkan NISN" required="">
					</div>
					<div class="">
						<p>Nama Lengkap</p>
						<input class="form-control" type="text" name="nama_lengkap" placeholder="Masukan Nama Lengkap" required="">
					</div>
					<div class="">
						<p>Username</p>
						<input class="form-control" type="text" name="user" placeholder="Masukan Username" required="">
					</div>
					<div class="">
						<p>Password</p>
						<input class="form-control" type="password" name="pass" placeholder="Masukan Password" required="">
					</div>
					<label class="anim">
						<input type="checkbox" class="checkbox">
						<span>I Accept Terms &amp; Conditions</span>
					</label>
					<input type="submit" class="btn btn-danger" name="simpan" value="Register">
				</form>
			</div>
		</div>
	<section class="contact pb-8" id="contact">
				<!-- //contact form -->
			</div>
				<!-- map -->
				<div class="col-lg-12 map" data-aos="flip-left" data-aos-easing="ease-out-cubic" data-aos-duration="2000">
					<iframe src="" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				</div>
				<!-- //map -->
		</div>
	</section>
	<?php if ($this->session->flashdata('error')) {
    echo '
	<script>
		swal({
			title: "Gagal!",
			text: "Register Gagal, Username Sudah Terdaftar",
			type: "error",
			confirmButtonText: "Ok"
		});
	</script>';
}?>
