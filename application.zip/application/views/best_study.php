<div class="middle-sec-agile">
		<div class="container">
			<h4 style="Font-Family:Times New Roman">SMP PNIEL MEDAN</h4>
			<ul>
				<li>
					<div class="midle-left-w3l">
						<span class="fa fa-check" aria-hidden="true"></span>
					</div>
					<div class="middle-right">
						<h5>Cerdas Dan Berakhlak Mulia</h5>
						<p></p>
					</div>
					<div class="clearfix"></div>
				</li>
				<li>
					<div class="midle-left-w3l">
						<span class="fa fa-check" aria-hidden="true"></span>
					</div>
					<div class="middle-right">
						<h5>Disiplian dan Jujur</h5>
						<p></p>
					</div>
					<div class="clearfix"></div>
				</li>
				<li>
					<div class="midle-left-w3l">
						<span class="fa fa-check" aria-hidden="true"></span>
					</div>
					<div class="middle-right">
						<h5>Ramah dan Santun</h5>
						<p></p>
					</div>
					<div class="clearfix"></div>
				</li>
			</ul>
		</div>
		</div>
	</div>
