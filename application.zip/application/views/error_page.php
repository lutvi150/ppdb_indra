<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/costume_not_found.css">
	<title>Not Found</title>
</head>
<body>
<div class="container">
  <div class="big_text text">
    <h1>4<span class="color_blue">0</span>4</h1>
    <p>Page not found <a href="<?=base_url()?>">Home</a></p>
  </div>
  <div class="small_texts">

    <p >
      404
    </p>
    <p >
      404
    </p>
    <p class="text_3">
      404
    </p>
    <p class="text_4">
      404
    </p>
    <p class="text_5">
      404
    </p>
    <p class="text_6">
      404
    </p>
    <p class="text_7">
      404
    </p>
    <p class="text_8">
      404
    </p>
    <p class="text_9">
      404
    </p>
    <p class="text_10">
      404
    </p class="text_11">
    <p>
      404
    </p>
    <p class="text_12">
      404
    </p>
    <p class="text_13">
      404
    </p>
  </div>
</div>
</body>
</html>
